// Import the functions you need from the SDKs you need
import { initializeApp } from "https://www.gstatic,com/firebasejs/10.1.0/firebase-app.js";
import { getAuth,googleAuthProvider } from "firebase/https://www.gstatic,com/firebasejs/10.1.0/firebase-auth.js";
import { GoogleAuthProvider } from "firebase/auth/web-extension";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyBb2Sh1wHOncZMaczp0pN55fmEYSS5paik",
  authDomain: "cosima2024-caa23.firebaseapp.com",
  projectId: "cosima2024-caa23",
  storageBucket: "cosima2024-caa23.appspot.com",
  messagingSenderId: "1089668841435",
  appId: "1:1089668841435:web:a5eb3e72015abc300031fe",
  measurementId: "G-5D7K4TYCYQ"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
auth.languageCode='en'
const Provider = new GoogleAuthProvider();